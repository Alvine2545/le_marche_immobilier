<?php

namespace App\Http\Livewire;

use Livewire\Component;

class OffrePremiumComponent extends Component
{
    public function render()
    {
        return view('livewire.offre-premium-component')->layout('layouts.index');
    }
}
