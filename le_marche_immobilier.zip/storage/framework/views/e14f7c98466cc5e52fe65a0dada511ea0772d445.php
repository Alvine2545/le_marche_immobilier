<div>
    <?php if($typeService == 0): ?>
        <?php echo $__env->make('livewire.services.acheter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($typeService == 1): ?>
        <?php echo $__env->make('livewire.services.mettre_en_location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($typeService == 2): ?>
        <?php echo $__env->make('livewire.services.vendre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php elseif($typeService == 3): ?>
            <?php echo $__env->make('livewire.services.louer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>


    <?php $__env->startPush('scripts'); ?>
    <script>
        var cities = <?php echo json_encode($cities, 15, 512) ?>;
        $('#city-input').typeahead({
            source: cities, 
            autoSelect: true
        });
    </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\resources\views/livewire/services-component.blade.php ENDPATH**/ ?>