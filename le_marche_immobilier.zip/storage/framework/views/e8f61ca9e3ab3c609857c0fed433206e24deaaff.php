<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>