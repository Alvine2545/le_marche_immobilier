<?php echo e($slot); ?>

<?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>