<div>
    <div class="fh5co-page-title div-custom section1-home">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row">
                        <div
                            class="col-md-12 col-sm-12 col-xs-12 text-center text-color">
                            <div class="row">
                                <h1></h1>
                                <h1></h1>
                            </div>
                            <div class="all-title-box">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12"
                                            style="margin: 2%; text-align: center;">

                                            <h2 class="h1 text-color">Bienvenue sur</h2>
                                            <h1 class="title h1 text-color"> LE MARCHE DE L'IMMOBILIER</h1>
                                            <h3 class=" text-black" style="font-size: 1.5rem; font-weight: bold;">Achetez, louez ou vendez un bien immobilier au Bénin</h3><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div id="fh5co-blog-section" class="fh5co-section-gray" style="margin-top: 5%;">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center animate-box">
                            <h2 class="text-center text-color"></h2>
                            
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row row-bottom-padded-md">
                        <div class="col-lg-2 col-md-3 col-sm-1 col-xs-1"></div>
                        <?php $__currentLoopData = $actualites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actualite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                   
                            <h3 class="title" style="color: black; text-center"><?php echo e($actualite->reference); ?> Titre de l'actualité</h3>
                            <div class="col-md-12">
                                <img src="../storage/<?php echo e($actualite->photo); ?>" class="img-fluid" alt="" style="margin: auto; ">
                            </div>
                            <div class="col-md-8 col-sm-8 col-xs-8 ">
                                <p style="font-size: 11px; font-weight: bold; text-align: center;" >
                                    <?php
                                        echo $actualite->description;
                                    ?>
                                </p>
                            </div>
                            <div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="clearfix visible-md-block"></div> -->
                    </div>
                </div>
            </div>
            <div id="">
                
                <footer class="container-fluid mt-5">
                    <div class="row pt-5">
                        <div class="col-md-3"></div>
                        <div class="col-md-6 separator"></div>
                        <div class="col-md-3"></div>
                    </div>
                    <div class="row p-3">
                        <div class="col-md-4"></div>
                        <div class="col-md-4 social-media text-center">
                            <i class="fa-brands fa-facebook p-1"></i>
                            <i class="fa-brands fa-instagram p-1"></i>
                            <i class="fa-brands fa-linkedin p-1"></i>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                    <div class="row">
                        <p class="text-light text-center">© Tout droit réservé EREBI SCI 2022</p>
                    </div>
                </footer>
</div>
<?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\resources\views/livewire/actualites.blade.php ENDPATH**/ ?>