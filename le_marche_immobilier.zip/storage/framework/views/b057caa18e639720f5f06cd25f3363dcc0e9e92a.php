<div class="row">
  <?php if(session()->has('add')): ?>
    <div class="col-xl-12 alert alert-success">
      <?php echo e(session('add')); ?>

    </div>
    <?php endif; ?>
    <div class="col-xl-12" wire:ignore>
        <div class="welcome">
                  
            <h1>Hello, <?php echo e(Auth::user()->name); ?></h1>
            <p>Bienvenue dans l'espace administrateur du marché de l'immobilier.</p>
        </div>
        <div class="my-4">
            <button class="btn btn-oval btn-primary btn-gradient mr-2">14 Messages</button>
            
        </div>
        <div class="h-scroll">
            <div class="row">
                <div class="col-8 col-md-4">
                    <div class="cardbox">
                        <div class="cardbox-body">
                            <div class="clearfix mb-2">
                                <div class="float-right">
                                    <small><em class="ml-2 ion-md-arrow-dropup"></em></small>
                                </div>
                                <div class="float-left">
                                    <small>Acteurs immobilier</small>
                                </div>
                            </div>
                            <div class="h3" data-counter="<?php echo e(count($users)); ?>">0</div>
                            <div class="text-center mt-3">
                                <div class="sparkline" id="sparkline1" data-bar-color="#42a5f5"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-8 col-md-4">
                    <div class="cardbox">
                        <div class="cardbox-body">
                            <div class="clearfix mb-2">
                            <div class="float-right">
                                <small><em class="ml-2 ion-md-arrow-dropdown"></em></small>
                            </div>
                            <div class="float-left">
                                <small>Partenaires Officiels</small>
                            </div>
                            </div>
                            <div class="h3" data-counter="<?php echo e(count($partners)); ?>">0</div>
                            <div class="text-center mt-3">
                            <div class="sparkline" id="sparkline2" data-bar-color="#42a5f5"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-8 col-md-4">
                    <div class="cardbox">
                        <div class="cardbox-body">
                            <div class="clearfix mb-2">
                            <div class="float-right">
                                <small><em class="ml-2 ion-md-arrow-dropup"></em></small>
                            </div>
                            <div class="float-left">
                                <small>Administrateurs</small>
                            </div>
                            </div>
                            <div class="h3" data-counter="<?php echo e(count($admins)); ?>">0</div>
                            <div class="text-center mt-3">
                            <div class="sparkline" id="sparkline3" data-bar-color="#42a5f5"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
    <div class="col-lg-12">

        <div class="card shadow mb-4">
            <!-- Card Header - Accordion -->
            <a href="#basicInfo" class="d-block card-header py-3" style="text-decoration: none;" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="basicInfo">
                <h6 class="m-0 font-weight-bold text-primary">Informations basiques du sponsor officiel <span class="float-right ion-md-arrow-dropdown"></span></h6>
                
            </a>
            <!-- Card Content - Collapse -->
            <div class="collapse show" id="basicInfo" style="">
                <div class="card-body">
                    <form action="" method="post" wire:submit.prevent='store' enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('post'); ?>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="form-group">
                                  <label for="">Nom du sponsor</label>
                                  <input required type="hidden" wire:model='identifiant' >                                  
                                  <input required type="text" name="nom" wire:ignore wire:model='nom' value="" id="" class="form-control" placeholder="" aria-describedby="helpId">
                                                                  </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="form-group">
                                  <label for="">Logo</label> <br>
                                  <input type="file" wire:model='logoSociete' id="" placeholder="" aria-describedby="helpId" required>
                                </div>
                                <img src="../storage/<?php echo e($logoSociete); ?>" alt="logo" class="img-fluid" width="250px">
                            </div>
                            <div class="col-lg-12">
                                <div class="form-group">
                                  <label for="">Quelques détails sur le sponsor</label> <br>
                                  <textarea class="form-control" name="description" wire:model='description' id="" cols="80" rows="5"></textarea>
                                </div>
                            </div>

                        </div>
                        <button type="submit" class="btn btn-primary btn-rounded-md px-3">Sauvegarder</button>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
                
    </div>
</div><?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\resources\views/livewire/admin/admin-home-component.blade.php ENDPATH**/ ?>