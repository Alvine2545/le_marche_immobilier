<div class="fh5co-page-title section1" style="height: 350px;">
            <div class="overlay"></div>
                <div class="container">
                    <div class="row">
                        <div class="col-md-12 animate-box fadeInUp animated-fast text-center text-color">
                            <div class="row"><h1></h1></div>
                            <h1 class="title"> Acceuil >> Services >> Acheter</h1>
                            <div class="div-form">
                                <form action="#" class="search-property-1">
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <!-- <label for="#">Location</label> -->
                                                <div class="form-field">
                                                    <div class="select-wrap">
                                                        <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                                                        
                                                        <select name="" id="" class="form-control form-control-header" style="height: 45px !important;">
                                                            <option value="">Types de bien</option>
                                                            <?php $__currentLoopData = $type_biens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->libelle); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <!-- <label for="#">Property Type</label> -->
                                                <div class="form-field">
                                                    <div class="select-wrap">
                                                        <div class="icon"><span class="ion-ios-arrow-down"></span></div>
                                                        <select name="" id="" class="form-control form-control-header" style="height: 45px !important;">
                                                            <option value="" selected>Situation géographique</option>
                                                            <?php for($i = 0; $i < count($cities); $i++): ?>
                                                                <option value="<?php echo e($cities[$i]); ?>"><?php echo e($cities[$i]); ?></option>
                                                            <?php endfor; ?>
                                                            
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                                <div class="form-group">
                                                    <!-- <label for="#">Budget maximum</label> -->
                                                    <div class="form-field">
                                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                                        <input type="text" class="form-control form-control-header" placeholder="Budget maximum">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-1"></div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-5 col-sm-5 col-xs-5"></div>
                                            <div class="col-md-2 col-md-offset-5 col-sm-2 col-sm-offset-5 col-xs-3 col-xs-offset-5" style="margin-left: 0% ;">
                                                <div class="form-group">
                                                    <div class="form-field">
                                                        <input type="submit" value="Achetez" class="form-control form-control-header  btn-round-custom btn-primary">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
            
                </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h3 class="text-center text-color">Achat de biens immobiliers</h3>
                    <div class="row">
                        <div class="col-md-12 animate-box">

                            <div class="feature-left">
                                <span class="icon ">
                                    <img src="<?php echo e(asset('images/doctors-1.jpg')); ?>" alt="" class="icon-custom img-responsive">
                                </span>
                                <div class="feature-copy">
                                    <h3>Move House</h3>
                                    <p>Facilis ipsum reprehenderitacilis ipsum reprehenderitacilis ipsum reprehenderitacilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit 
                                        acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit nemoreprehenderit nemoreprehenderit nemoreprehenderit nemoreprehenderit nemoreprehenderit nemoreprehenderit 
                                        itacilis ipsum reprehenderitacilis ipsum reprehenderitacilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum
                                        reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit
                                        acilis ipsum reprehenderit acilis ipsum reprehenderit acilis ipsum reprehenderit acilinemoreprehenderit nemoreprehenderit nemo molestias. Aut cum mollitia reprehenderit.</p>
                                </div>
                            </div>
                        </div>                        
                    </div>
                </div>
            </div>
            <div id="">
                <div class="container">
                    <div class="row ">
                        <div class="col col-md-12 col-sm-12 col-xs-12 animate-box icon-custom">
                            <div class="col-md-3 col-sm-4 col-xs-4">
                                <img src="<?php echo e(asset('images/doctors-1.jpg')); ?>" class="img-rounded-custom img-responsive"
                                    style="margin-left: -30.19px;"></i>
                            </div>
                            <div class="col-md-9 col-sm-8 col-xs-8">
            
                                <h1 class="title text-color ">Nom de la propriété</h1>
                                <h3>1 000 000 FCFA</h3>
                                <p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Aut cum mollitia
                                    reprehenderit. Aut cum mollitia reprehenderit.</p>
                                <!-- <p><a href="#">Learn More</a></p> -->
                                <hr style="height: 5px; background-color: black;">
                                <div class="row">
                                    <div class="col-md-2 col-sm-2 col-xs-2"><span> <i class="icon-rdio"></i> Organisation</span>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-2"><span> <i class="icon-location"></i> Localisation</span>
                                    </div>
                                    <div
                                        class="col-md-offset-5 col-md-3 col-sm-3 col-sm-offset-3 col-xs-3 col-xs-offset-5 d-flex justify-content-end">
                                        <span class=""> <a href="<?php echo e(url('offres/1')); ?>" style="color: black; border: none; cursor: pointer; text-decoration: none;" value="Consulter l'offre"
                                                class="btn btn-round-custom"></a></span></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div><br>
            <div id="">
                <div class="container">
                    <div class="row ">
                        <div class="col-md-12 animate-box feature-left icon-custom">
                                <div class="icon">
                                    <img src="images/doctors-1.jpg" class="img-rounded-custom img-responsive icon-wallet" style="margin-left: %;"></i>
                                </div>
                                <div class="feature-copy feature-copy-custom">
                                    
                                    <h1 class="title text-color ">Nom de la propriété</h1>
                                    <h3>1 000 000 FCFA</h3>
                                    <p>Facilis ipsum reprehenderit nemo molestias. Aut cum mollitia reprehenderit. Aut cum mollitia reprehenderit. Aut cum mollitia reprehenderit.</p>
                                    <!-- <p><a href="#">Learn More</a></p> -->
                                    <hr style="height: 5px; background-color: black;">
                                    <div class="row">
                                        <div class="col-md-2 col-sm-2 col-xs-2"><span> <i class="icon-rdio"></i> Organisation</span></div>
                                        <div class="col-md-2 col-sm-2 col-xs-2"><span> <i class="icon-location"></i> Localisation</span></div>
                                        <div class="col-md-offset-5 col-md-3 col-sm-3 col-sm-offset-3 col-xs-3 col-xs-offset-5 d-flex justify-content-end"><span class=""> <input type="submit" value="Consulter l'offre" class="btn btn-round-custom"></span></div>
                                    </div>
                                </div>
                        </div>
                    </div>
                    
                </div>
            </div><br>
            
            </div><?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\resources\views/livewire/services/louer.blade.php ENDPATH**/ ?>