<!DOCTYPE html>
<html class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Le Marché de l'immobilier</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Free HTML5 Template by FREEHTML5.CO" />
    <meta name="keywords" content="free html5, free template, free bootstrap, html5, css3, mobile first, responsive" />
    <meta name="author" content="FREEHTML5.CO" />

    <!-- Facebook and Twitter integration -->
    <meta property="og:title" content="" />
    <meta property="og:image" content="" />
    <meta property="og:url" content="" />
    <meta property="og:site_name" content="" />
    <meta property="og:description" content="" />
    <meta name="twitter:title" content="" />
    <meta name="twitter:image" content="" />
    <meta name="twitter:url" content="" />
    <meta name="twitter:card" content="" />

    <!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
    <div wire:ignore>
    <link rel="shortcut icon" href="images/Logo-1.png">
    <link rel="stylesheet" href="css/lestyle.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.3.0/css/all.min.css"
    integrity="sha512-SzlrxWUlpfuzQ+pcUCosxcglQRNAq/DZjVsC0lE40xsADsfeQoEypE+enwcOiGjk/bSuGGKHEyjSoQ1zVisanQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:300,400,700,300' rel='stylesheet' type='text/css'>

    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>    

    <!-- Animate.css -->
    <link rel="stylesheet" href="css/animate.css">
    <!-- Icomoon Icon Fonts-->
    <link rel="stylesheet" href="css/icomoon.css">
    <!-- Bootstrap  -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <!-- Superfish -->
    <link rel="stylesheet" href="css/superfish.css">
    <!-- Flexslider  -->
    <link rel="stylesheet" href="css/flexslider.css">
    <!-- Magnific Popup -->
    <link rel="stylesheet" href="css/magnific-popup.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="css/bootstrap-datepicker.min.css">
    <!-- CS Select -->
    <link rel="stylesheet" href="css/cs-select.css">
    <link rel="stylesheet" href="css/cs-skin-border.css">
    <link rel="stylesheet" href="css/style.css">

    <style>
        .error{
            color: red;
            font-weight: bold;
        }
    </style>
    <!-- Modernizr JS -->
    <script src="js/modernizr-2.6.2.min.js"></script>
    <!-- FOR IE9 below -->
    <!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
    <?php echo \Livewire\Livewire::styles(); ?>

</head>

<body>
    <div id="fh5co-wrapper">
        <div id="fh5co-page">
            <header id="fh5co-header-section" class="sticky-banner">
                <div class="container">
                    <div class="nav-header">
                        <a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
                        <h1 id="fh5co-logo"><a href="index.html"><img class="icon-home img-responsive" style="height: 150px; margin-top: -45px;" src="images/Logo-1.png"
                                                alt="" id="navLogo"> </a></h1>
                        <!-- START #fh5co-menu-wrap -->
                        
                        <nav id="fh5co-menu-wrap" role="navigation">
                            <ul class="sf-menu " id="fh5co-primary-menu">
                                    <li class="active" style=""><a href="<?php echo e(url('/')); ?>" style="margin-top: 30px;">Acceuil</a></li>
                                    <li style="margin-top: 30px; ">
                                        <a href="" class="fh5co-sub-ddown">Services</a>
                                        <ul class="fh5co-sub-menu">
                                            <li class=""><a href="<?php echo e(url('/0')); ?>">Achetez</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a href="<?php echo e(url('/1')); ?>">Mettez en location</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a href="<?php echo e(url('/2')); ?>">Vendez</a></li>
                                            <li>
                                                <hr class="dropdown-divider">
                                            </li>
                                            <li><a href="<?php echo e(url('/3')); ?>">Louez</a></li>
                                        </ul>
                                    </li>
                                    <li style="margin-top: 30px; "><a href="<?php echo e(url('/offres')); ?>">Offres des partenaires</a></li>
                                    <li style="margin-top: 30px; "><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
                                    <li style="margin-top: 20px; ">
                                        <a href="" class="" data-toggle="modal" data-target="#exampleModal">
                                            <i class="fa-solid fa-circle-user" style="font-size: 3em; color: #EFCF4F ;"></i>
                                        </a>
                                    </li>
                                </ul>
                                
                        </nav>
                    </div>
                </div>
		    </header>
            <!-- Modal -->
            <div class="modal fade  " id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
                aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered modal-md " role="document">
                    <div class="modal-content modal-custom">
                        <!-- <div class="modal-header">
                            <h5 class="modal-title text-center" id="exampleModalLabel" style="color: #EFCF4F; font-weight: bold; text-align: center !important;">Connectez vous à votre compte</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div> -->
                        <br>
                        <h5 class="modal-title text-center" id="exampleModalLabel"
                            style="color: #EFCF4F; font-weight: bold; text-align: center !important;">Connectez vous à votre compte
                        </h5>
                        <!-- <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button> -->
                        <div class="modal-body">
                            <!-- Contenu du modal -->
                            <form>
                                <div class="form-group">
                                    <!-- <label for="exampleFormControlInput1">Email address</label> -->
                                    <input type="email" class="form-control modal-custom" id="exampleFormControlInput1"
                                        placeholder="Votre nom d'utilisateur"><br><br>
                                </div>
                                <div class="form-group">
                                    <!-- <label for="exampleFormControlInput1">Email address</label> -->
                                    <input type="email" class="form-control modal-custom" id="exampleFormControlInput1"
                                        placeholder="Votre nom d'utilisateur">
                                </div>
                            </form>
                            <p>Vous n'avez pas de compte ? Créez un compte <a class="text-black" data-toggle="modal"
                                    data-target="#incriptionModal">ici</a></p><br>
                            <button type="button" class="btn btn-custom btn-block">Connexion</button>
                        </div>
                        <!-- <div class="modal-footer">
                            <button type="button" class="btn btn-custom">Connexion</button>
                        </div> -->
                    </div>
                </div>
            </div>
            
            <?php echo $__env->yieldContent('content'); ?>
                <footer class="container-fluid mt-5">
                    <div class="row pt-5">
                        <div class="col-md-3"></div>
                        <div class="col-md-6 separator"></div>
                        <div class="col-md-3"></div>
                    </div>
                    <div class="row p-3">
                        <div class="col-md-4"></div>
                        <div class="col-md-4 social-media text-center">
                            <i class="fa-brands fa-facebook p-1"></i>
                            <i class="fa-brands fa-instagram p-1"></i>
                            <i class="fa-brands fa-linkedin p-1"></i>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                    <div class="row">
                        <p class="text-light text-center">© Tout droit réservé EREBI SCI 2022</p>
                    </div>
                </footer>
        </div>
        <!-- END fh5co-page -->

    </div>
    <!-- END fh5co-wrapper -->

    <!-- jQuery -->
    <script src="js/jquery.min.js"></script>
    <!-- jQuery Easing -->
    <script src="js/jquery.easing.1.3.js"></script>
    <!-- Bootstrap -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Waypoints -->
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/sticky.js"></script>
    <!-- Superfish -->
    <script src="js/hoverIntent.js"></script>
    <script src="js/superfish.js"></script>
    <!-- Flexslider -->
    <script src="js/jquery.flexslider-min.js"></script>
    <!-- Date Picker -->
    <script src="js/bootstrap-datepicker.min.js"></script>
    <!-- CS Select -->
    <script src="js/classie.js"></script>
    <script src="js/selectFx.js"></script>
    <script src="js/modernizr-2.6.2.min.js"></script>

    <!-- Main JS -->
    <script src="js/main.js"></script>
    <script>
        window.addEventListener('alert', event => { 
             toastr[event.detail.type](event.detail.message, 
             event.detail.title ?? ''), toastr.options = {
                    "closeButton": true,
                    "progressBar": true,
                }
            });
</script>
    <?php echo \Livewire\Livewire::scripts(); ?>

</body>

</html><?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\resources\views/layouts/home.blade.php ENDPATH**/ ?>