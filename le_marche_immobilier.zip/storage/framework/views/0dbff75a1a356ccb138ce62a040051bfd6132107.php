<div class="container-fluid">
    <h1 class="h3 mb-4 text-gray-800">Dashboard - Nos partenaires</h1>
<div class="row mb-4">

</div>

<div class="row mb-4">
    <div class="col-6">
        <ul class="nav justify-content-start ">
            <li class="nav-item">
              <a class="nav-link active disabled border border-warning bg-ligth" href="#">Toute les partenaires</a>
            </li>
            <li class="nav-item">
              <a class="nav-link border-bottom border-warning " href="#">Les anciens partenaires</a>
            </li>
        </ul>
    </div>
    <div class="col-6 ">

        <div class="text-right">
            <button type="button" class="btn btn-success px-3" data-toggle="modal" data-target="#exampleModal">
                Ajouter un nouveau partenaire
            </button>
        </div>


        <div wire:ignore class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <form action="" method="post" wire:submit.prevent='store'>
                    <?php echo csrf_field(); ?>
                    <div class="modal-header bg-primary text-white">
                        <h5 class="modal-title" id="exampleModalLabel">Nouveau partenaire</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">

                            <div class="row">
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Nom de l'entité</label>
                                      <input type="text" wire:model="nom" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Numero IFU</label>
                                      <input type="text" wire:model="ifu" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Situation géographique</label>
                                      <input type="text" wire:model="adresse" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Lien du site web de l'entité</label>
                                      <input type="text" wire:model="site" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Adresse email</label>
                                      <input type="email" wire:model="email" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Téléphone</label>
                                      <input type="text" wire:model="tel" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Logo de l'entité</label>
                                      <input type="file" wire:model="logo" id="" class="form-control" placeholder="" required="">
                                      
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div class="form-group">
                                      <label for="">Situation géographique</label>
                                      <textarea wire:model="description" id="" class="form-control" placeholder="" required="" cols="30" rows="10"></textarea>
                                      
                                    </div>
                                </div>

                            </div>

                    </div>
                    <div class="modal-footer bg-primary text-white">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-success">Enregistrer</button>
                    </div>
                </form>
                </div>
            </div>
        </div>

    </div>
</div>

<div class="row">
    <div class="col-12">
        
            </div>

    <div class="col-lg-12">

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Les partenaires</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th>Entité</th>
                                <th>Emai/Téléphone</th>
                                <th>Site web</th>
                                <th>Statut</th>
                                <!--th>Date Ajout</th-->
                                <th>Options</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $partenaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->name); ?></td>
                                    <td><a href="mailto:<?php echo e($item->email); ?>"><?php echo e($item->email); ?></a> / <a href="tel:<?php echo e($item->tel); ?>"><?php echo e($item->tel); ?></a></td>
                                    <td><?php echo e($item->site); ?></td>
                                    <td>
                                        <?php if($item->status): ?>
                                            <span class="text-success">Demande acceptée</span>
                                        <?php else: ?>
                                            <span class="text-success">Demande en attente</span>
                                        <?php endif; ?>
                                        
                                    </td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <?php if($item->status): ?>
                                                <button class="btn btn-warning" data-toggle="modal" data-target="#voirModal<?php echo e($item->id); ?>">Voir</button>
                                                <button type="button"  class="btn btn-danger" data-toggle="modal" data-target="#supprimerModal<?php echo e($item->id); ?>">
                                                    Supprimer
                                                </button>
                                            <?php else: ?>
                                                <button class="btn btn-primary" wire:click="storeOffre(<?php echo e($item->id); ?>)">Approuver</button>
                                                <button type="button" class="btn btn-danger" data-toggle="modal" data-target="#ejecterModal<?php echo e($item->id); ?>">
                                                    Rejeter
                                                </button>
                                                <button class="btn btn-warning" data-toggle="modal" data-target="#voirModal<?php echo e($item->id); ?>">Voir</button>
                                            <?php endif; ?>
                                            
                                        </div>

                                        <!-- Supprimer une demande -->
                                        <div class="container modal fade" id="supprimerModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="supprimerModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="supprimerModalLabel">Suppression du partenaire <b class="text-primary"><?php echo e($item->name); ?></b></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <form action="" method="post">
                                                        <p>
                                                            Cette action est irréverssible !
                                                            Lorsque vous supprimez un partenaire, un mail lui sera envoyé et il est directement supprimer de votre système. <br>
                                                        </p>
                                                        <p>Toutefois, vous pouvez ajouter un nouveau partenaire.</p>
                                                        <input type="hidden" name="idPer" value="<?php echo e($item->id); ?>">
                                                        
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                            <button type="submit" class="btn btn-danger" wire:click='delete<?php echo e($item->id); ?>'>Confirmer</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Rejeter une demande -->
                                        <div class="container modal fade" id="ejecterModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="ejecterModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="ejecterModalLabel">Rejetter la demande de <b class="text-primary"><?php echo e($item->name); ?></b></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <form action="" method="post">
                                                        <p>
                                                            Lorsque vous rejeter une demande, un mail est envoyé à l'entité et elle est directement considérée comme un ancien dans le système. <br>
                                                            Elle ne pourra pas :
                                                        </p>
                                                        <ul>
                                                            <li>Proposée ses offres</li>
                                                        </ul>
                                                        <p>Toutefois, vous pouvez ajouter un nouveau partenaire.</p>
                                                        <input type="hidden" name="idPer" value="<?php echo e($item->id); ?>">
                                                        
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                            <button type="button" class="btn btn-primary" wire:click='rejet(<?php echo e($item->id); ?>)'>Confirmer</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="container modal fade" id="voirModal<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="voirModalLabel<?php echo e($item->id); ?>" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="voirModalLabel">Détails de la demande de <b class="text-primary"><?php echo e($item->name); ?></b></h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">×</span>
                                                        </button>
                                                    </div>
                                                    <form action="" method="post">
                                                        
                                                        <ul>
                                                            <li>Les services fournis</li>
                                                        </ul>
                                                        <p><?php echo e($item->description); ?></p>
                                                        <input type="hidden" name="idPer" value="<?php echo e($item->id); ?>">
                                                        
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                                                            
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>




                </div><?php /**PATH C:\Users\Probook i5\OneDrive\Bureau\Eunice\le_marche_immobilier\resources\views/livewire/admin/partenaires/partenaires-component.blade.php ENDPATH**/ ?>