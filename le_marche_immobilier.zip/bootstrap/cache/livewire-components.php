<?php return array (
  'contact-component' => 'App\\Http\\Livewire\\ContactComponent',
  'offre-premium-component' => 'App\\Http\\Livewire\\OffrePremiumComponent',
  'offres-component' => 'App\\Http\\Livewire\\OffresComponent',
  'services-component' => 'App\\Http\\Livewire\\ServicesComponent',
  'show-offre-component' => 'App\\Http\\Livewire\\ShowOffreComponent',
  'users.achat-component' => 'App\\Http\\Livewire\\Users\\AchatComponent',
  'visitor-component' => 'App\\Http\\Livewire\\VisitorComponent',
  'admin.actualites-component' => 'App\\Http\\Livewire\\admin\\ActualitesComponent',
  'admin.admin-home-component' => 'App\\Http\\Livewire\\admin\\AdminHomeComponent',
  'admin.partenaires.partenaires-component' => 'App\\Http\\Livewire\\admin\\Partenaires\\PartenairesComponent',
);