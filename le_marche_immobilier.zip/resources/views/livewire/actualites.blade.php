<div>
    <div class="fh5co-page-title div-custom section1-home">
                <div class="overlay"></div>
                <div class="container">
                    <div class="row">
                        <div
                            class="col-md-12 col-sm-12 col-xs-12 text-center text-color">
                            <div class="row">
                                <h1></h1>
                                <h1></h1>
                            </div>
                            <div class="all-title-box">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-md-12 col-sm-12 col-xs-12"
                                            style="margin: 2%; text-align: center;">

                                            <h2 class="h1 text-color">Bienvenue sur</h2>
                                            <h1 class="title h1 text-color"> LE MARCHE DE L'IMMOBILIER</h1>
                                            <h3 class=" text-black" style="font-size: 1.5rem; font-weight: bold;">Achetez, louez ou vendez un bien immobilier au Bénin</h3><br>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

            <div id="fh5co-blog-section" class="fh5co-section-gray" style="margin-top: 5%;">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8 col-md-offset-2 text-center animate-box">
                            <h2 class="text-center text-color"></h2>
                            
                        </div>
                    </div>
                </div>
                <div class="container">
                    <div class="row row-bottom-padded-md">
                        <div class="col-lg-2 col-md-3 col-sm-1 col-xs-1"></div>
                        @foreach ($actualites as $actualite)                   
                            <h3 class="title" style="color: black; text-center">{{$actualite->reference}} Titre de l'actualité</h3>
                            <div class="col-md-12">
                                <img src="../storage/{{$actualite->photo}}" class="img-fluid" alt="" style="margin: auto; ">
                            </div>
                            <div class="col-md-8 col-sm-8 col-xs-8 ">
                                <p style="font-size: 11px; font-weight: bold; text-align: center;" >
                                    @php
                                        echo $actualite->description;
                                    @endphp
                                </p>
                            </div>
                            <div>

                            </div>
                        @endforeach
                        <!-- <div class="clearfix visible-md-block"></div> -->
                    </div>
                </div>
            </div>
            <div id="">
                {{-- <h3></h3>
                <div class="container">
                    
                    <div style="position:relative;">
                        <span style="position:fixed;bottom:0; left:85%; color:red;animation: blink 1s infinite; font-size:10em; z-index: 9999;">
                            &#9733;
                        </span>
                        <span style="position:fixed;bottom:0;left:85%;color:yellow;animation: blink 1s infinite 0.5s; font-size:10em; z-index: 9999;">
                            &#9733;
                        </span>
                        <span class="text-uppercase" style="z-index: 9999; white-space: pre-wrap; font-weight: bold; color: red; -webkit-text-stroke-color: white; position:fixed;bottom:75px;left:86%;font-size:24px;">  offres
premium</span>
                    </div>
                </div> --}}
                <footer class="container-fluid mt-5">
                    <div class="row pt-5">
                        <div class="col-md-3"></div>
                        <div class="col-md-6 separator"></div>
                        <div class="col-md-3"></div>
                    </div>
                    <div class="row p-3">
                        <div class="col-md-4"></div>
                        <div class="col-md-4 social-media text-center">
                            <i class="fa-brands fa-facebook p-1"></i>
                            <i class="fa-brands fa-instagram p-1"></i>
                            <i class="fa-brands fa-linkedin p-1"></i>
                        </div>
                        <div class="col-md-4"></div>
                    </div>
                    <div class="row">
                        <p class="text-light text-center">© Tout droit réservé EREBI SCI 2022</p>
                    </div>
                </footer>
</div>
