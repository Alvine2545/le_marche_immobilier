<div class="contact-section">
    <section class=" container align-items-center">
        <div class="row mt-4">
            <div class="col-md-6">
                <h1 class="text-light mt-lg-5">Contactez notre agence</h1>
                <div class="row-fluid">
                <div class="phone contact-elements mt-4">
                    <i class="fa-solid fa-phone p-1"></i>
                    <a class="text-light" style="text-decoration: none" href="tel:+229 57 69 69 99" >+229 57 69 69 99</a>
                </div>
                <div class="mail contact-elements  mt-4">
                    <i class="fa-solid fa-envelope p-1"></i>
                    <a href="mailto:erebisci@gmail.com" style="text-decoration: none" class="text-light">erebisci@gmail.com</a>
                </div>
                <div class="location contact-elements  mt-4">
                    <i class="fa-solid fa-location-dot p-1"></i>
                    <p class="text-light">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                </div>
                <div class="mail-box contact-elements  mt-4">
                    <img src="images/mailbox.svg" alt="">
                    <p class="text-light">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact_form float-end">
                    {{-- <div class="container"><h2 class="h2 title" style="color: white; margin-top: 3vh;">Remplissez ce formulaire pour nous contacter</h2></div><br> --}}
                    <div class=""><h2 class="h2 title" style="color: white; margin-top: 3vh; margin-left: 8px; margin-right: 8px;">Remplissez ce formulaire pour nous contacter</h2></div><br>
                    <form id="" class="row" action="" wire:submit.prevent='sendMessage' name="contactform" method="post">
                        @csrf
                        @method('post')
                        <!-- <fieldset class="row-fluid"> -->
                            {{-- <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div> --}}
                            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 col-sm-offset-1 col-xs-offset-1 col-md-offset-1 col-lg-offset-1">
                                <input type="text" wire:model='first_name' name="first_name" id="first_name" class="form-control" placeholder="Votre nom">
                                @error('first_name') <span class="error">{{ $message }}</span> @enderror
                                <br>
                            </div><div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                            {{-- <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div> --}}
                            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 col-sm-offset-1 col-xs-offset-1 col-md-offset-1 col-lg-offset-1">
                                <input type="email" wire:model='email' name="email" id="email" class="form-control" placeholder="Votre Email">
                                @error('email') <span class="error">{{ $message }}</span> @enderror
                                <br>
                            </div><div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                            {{-- <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div> --}}
                            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 col-sm-offset-1 col-xs-offset-1 col-md-offset-1 col-lg-offset-1">
                                <input type="text" wire:model='phone' name="phone" id="phone" class="form-control" placeholder="Votre téléphone">
                                @error('phone') <span class="error">{{ $message }}</span> @enderror
                                <br>
                            </div><div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                            {{-- <div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div> --}}
                            <div class="col-lg-10 col-md-10 col-sm-10 col-xs-10 col-sm-offset-1 col-xs-offset-1 col-md-offset-1 col-lg-offset-1">
                                <textarea class="form-control" wire:model='comments' name="comments" id="comments" rows="6"
                                    placeholder="Tapez votre message"></textarea>
                                    @error('comments') <span class="error">{{ $message }}</span> @enderror
                            </div><div class="col-lg-1 col-md-1 col-sm-1 col-xs-1"></div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center" style="padding: 5vh;">
                                <button type="submit" id="submit"
                                    class="btn btn-custom" style="color: white; font-weight: bold;" >Envoyer le message</button>
                            </div>
                        <!-- </fieldset> -->
                    </form>
                </div>
            </div>
        </div>
    </section>
</div>
