<div class="fh5co-page-title section1" style="height: 50% !important; height: 350px;">
    <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-sm-12 col-xs-12 animate-box fadeInUp animated-fast text-center text-color" wire:ignore>
                            
                    <div class="all-title-box">
                        <div class="container">
                            <div class="row">
                                <div class="col-md-12 col-sm-12 col-xs-12" style="margin: 3%; text-align: center;">
                                                    
                                    <h2 class="h1"></h2>
                                    <h1 class="title"> Acceuil >> Services >> Mettre en location</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
            <!-- <div id="fh5co-features"> -->
    @if (session()->has('message'))
        <div class="alert alert-success text-center">{{ session('message') }}</div>
    @endif
            <div id="">
                <h3></h3>
                <div class="container">
                    <h2 class="text-center text-color">Procédure de mise en location un biens immobiliers</h2>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left">
                            <p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur 
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo exercitationem 
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h2 class="text-center text-color">Etape 1 : Procédure de mise en location un biens immobiliers</h2>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left">
                            <p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h2 class="text-center text-color">Etape 2 : Procédure de mise en location un biens immobiliers</h2>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left">
                            <p>  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h2 class="text-center text-color">Etape 3 : Procédure de mise en location un biens immobiliers</h2>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left">
                            <p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h2 class="text-center text-color">Etape 4 : Procédure de mise en location un biens immobiliers</h2>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left">
                            <p>  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h2 class="text-center text-color">Etape 5 : Procédure de mise en location un biens immobiliers</h2>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left">
                              <p>  Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.
                                </p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div id="">
                <h3></h3>
                <div class="container">
                    <h3 class="text-center text-color"></h3>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left"> <p class="" style="text-align: center;"> Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.</p>
                            </div>
                        </div>
                    </div>
            
                </div>
            </div>
            <div id="">
                <h3></h3><br>
                <div class="container">
                    <h2 class="text-center text-color">Mettre en location un bien immobilier</h2>
                    <h3 class="text-center text-color">Remplissez ce formulaire pour mettre en location votre bien immobilier</h3><br>

                    <div class="row">
                        <h5 class="text-center text-color">Renseignez les informations sur vous</h5>
                        <div class="col-md-12 animate-box" wire:ignore>
                            <div class="feature-left">
                                <form method="post" wire:submit.prevent='store' class="search-property-1" enctype="multipart/form-data">
                                    @csrf
                                    @method('post')
                                    <div class="row" >
                                        <div class="col-md-3 col-sm-3 col-xs-3 col-lg-3 align-items-end">
                                            <span>Qui êtes-vous?</span>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-3 col-lg-3 align-items-end">
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" id="optionsRadios1" type="radio" name="optionsRadios" value="Particulier" wire:model='type_user'>Particulier
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-3 col-lg-3 align-items-end">
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" id="optionsRadios2" type="radio" wire:model='type_user' name="optionsRadios" value="Agent immobilier">Agent immobilier
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-3 col-xs-3 col-lg-3 align-items-end">
                                            <div class="form-check">
                                                <label class="form-check-label">
                                                    <input class="form-check-input" id="optionsRadios2" wire:model='type_user' type="radio" name="optionsRadios" value="Agence immobilière">Agence immobilière
                                                </label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control " placeholder="Nom" wire:model='name'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control " placeholder="Prénom" wire:model='prenom'>
                                                </div>
                                            </div>
                                        </div>
                                        @if ($type_user == "Agence immobilière")
                                            <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                                <div class="form-group">
                                                    <div class="form-field">
                                                        <div class="icon"><span class="ion-ios-search"></span></div>
                                                        <input type="text" class="form-control " placeholder="Nom de l'agence" wire:model='nameAgence'>
                                                    </div>
                                                </div>
                                            </div>
                                        @endif
                                        
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Email" wire:model='email'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Téléphone" wire:model='telephone'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Mot de passe" wire:model='password'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Confirmez le mot de passe" wire:model='confirmed_password'>
                                                </div>
                                            </div>
                                        </div>
                                    </div><br>
                                    <div class="row">   
                                        <h5 class="text-center text-color">Renseignez les informations sur votre bien</h5>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <select name="" id="" class="form-control " style="height: 45px !important;" wire:model='ville'>
                                                            <option value="" selected>Situation géographique</option>
                                                            @for($i = 0; $i < count($cities); $i++)
                                                                <option value="{{$cities[$i]}}">{{$cities[$i]}}</option>
                                                            @endfor
                                                            
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Désignation du bien" wire:model='reference'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Surface totale" wire:model='surface'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Coût minimal" wire:model='prix_min'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="Coût maximal" wire:model='prix_max'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <select name="" id="" class="form-control " style="height: 45px !important;" wire:model='type_bien'>
                                                            <option value="" selected>Type du bien</option>
                                                            @foreach ($type_biens as $type_bien)
                                                                <option value="{{$type_bien->id}}">{{$type_bien->libelle}}</option>
                                                            @endforeach
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="nombre de pièce" wire:model='nbr_piece'>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-4 col-xs-4 col-lg-4 align-items-end">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <div class="icon"><span class="ion-ios-search"></span></div>
                                                    <input type="text" class="form-control" placeholder="nombre de chambre" wire:model='nbr_chambre'>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row form-group form-field">
                                        <div class="col-md-5 col-sm-5 col-xs-5"></div>
                                        <div class="col-md-3 col-md-offset-4 col-sm-3 col-sm-offset-4 col-xs-4 col-xs-offset-4 btn-text form-control btn btn-primary" style="margin-left: 0% ;">
                                            <div class="">
                                                <div class="" style="">
                                                    <label for="">Photos du bien</label><input type="file" value="Photo du lieu" class="" wire:model='photo'>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-5 col-sm-5 col-xs-5"></div>
                                        <div class="col-md-12 col-sm-12 col-xs-12" style="margin-left: 0% ;">
                                            <div class="form-group">
                                                <div class="form-field">
                                                    <textarea name="" id="" cols="30" rows="10"placeholder="Tapez votre message" class="form-control" wire:model='description'></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-4 col-sm-5 col-xs-5"></div>
                                        <div class="col-md-3 col-md-offset-5 col-sm-3 col-sm-offset-5 col-xs-3 col-xs-offset-5" style="margin-left: 4% ;">
                                            <div class="form-group">
                                                <div class="form-field" style="margin-bottom: 30px; margin-top: 20px;">
                                                    <input type="submit" value="Envoyez le formulaire" class="btn-text form-control btn btn-primary btn-custom">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    
                </div>
                
            </div>
            <div id="">
                <h3></h3>
                {{-- <div class="container">
                    <h3 class="text-center text-color"></h3>
                    <div class="row">
                        <div class="col-md-12 animate-box" wire:ignore>
            
                            <div class="feature-left"> <p class="" style="text-align: center;"> Tempore, cupiditate eum.
                                Lorem ipsum dolor sit amet consectetur, adipisicing elit. Aut quod eum repellendus tenetur
                                perferendis harum debitis reiciendis deleniti nisi? Ipsum, architecto praesentium. Quo
                                exercitationem
                                inventore consectetur eos! Tempore, cupiditate eum.</p>
                            </div>
                        </div>
                    </div>
            
                </div> --}}
                {{-- <div style="position:relative;">
                    <span style="position:fixed;bottom:0;left:85%;color:red;animation: blink 1s infinite; font-size:10em;">
                        &#9733;
                    </span>
                    <span style="position:fixed;bottom:0;left:85%;color:yellow;animation: blink 1s infinite 0.5s; font-size:10em;">
                        &#9733;
                    </span>
                    <span class="text-uppercase"
                        style="white-space: pre-wrap; font-weight: bold; color: red; -webkit-text-stroke-color: white; position:fixed;bottom:70px;left:85%;font-size:24px;">  offres
premium</span>
                </div> --}}
                </div>
            </div>
</div>